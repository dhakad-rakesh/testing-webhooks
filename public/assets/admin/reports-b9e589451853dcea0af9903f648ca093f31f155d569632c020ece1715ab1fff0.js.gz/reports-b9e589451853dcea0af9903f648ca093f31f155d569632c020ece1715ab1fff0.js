// $(function() {
//   var tableTitle = $('.dt-reports').data('title');
//   $('.dt-reports').DataTable({
//     aaSorting: [],
//     searching: false,
//     paging: false,
//     info: false,
//     dom: '<"html5buttons"B>lTfgitp',
//     buttons: [
//       {extend: 'csv'},
//       {extend: 'excel', title: $('.dt-reports').data(`${tableTitle}`)},
//       {extend: 'pdf', title: $('.dt-reports').data(`${tableTitle}`)}
//     ]
//   });
// });
